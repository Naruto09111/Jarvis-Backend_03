# Backend patch: models advertised by a gateway engine (e.g. "01-ai/yi-large")

## The bug (verified by running the real functions)
`GET /v1/models` returned `{"data":[]}` while `/v1/info` reported model `01-ai/yi-large`.

* `cloud_router.get_provider()` treats **any** model id containing "/" as an OpenRouter model.
* `routes.list_models()` removes every "cloud" model id unless the engine is `litellm`,
  then falls back to Ollama (`list_local_models()`), which is empty on your PC.
  => `01-ai/yi-large` was filtered out and the list was empty.
* The chat path (`_uses_direct_cloud_router`) had the same flaw: even if the model had been
  selected, the request would go to the direct OpenRouter router (needs `OPENROUTER_API_KEY`)
  instead of the engine that advertised the model.

## The fix (src/openjarvis/server/routes.py only)
Models advertised by `litellm`, `omniroute`, `nim`, or by any non-"cloud" engine inside a
MultiEngine are now owned by that engine: listed in /v1/models and routed to it.
Direct cloud models (the "cloud" engine / Cloud Models tab) behave exactly as before.

## Apply on Windows (CMD)
Option A - drop-in file (only if your routes.py is identical to the OpenJarvis-Backend-NoDocker.zip one):

    copy /Y src\openjarvis\server\routes.py D:\Jarvis-Backend_2\OpenJarvis-main\src\openjarvis\server\routes.py

Option B - patch (safer if you changed the file):

    cd /d D:\Jarvis-Backend_2\OpenJarvis-main
    git apply --check routes.py.diff
    git apply routes.py.diff

(Copy the new test too: tests\server\test_gateway_model_routing.py)

## Restart and verify
Stop `jarvis serve` (Ctrl+C), start it again, then:

    curl.exe http://127.0.0.1:8000/v1/models
    curl.exe http://127.0.0.1:8000/v1/info

`/v1/models` must now list your model. If it is STILL empty, the engine itself is not
advertising any model (check the `jarvis serve` startup output, NIM_API_KEY / OMNIROUTE_API_KEY /
host settings): that is a different problem than the filter fixed here, and the frontend
will say so in Settings -> Connection.

Optional test: `pytest tests/server/test_gateway_model_routing.py`
